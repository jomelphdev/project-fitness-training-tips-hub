<?php
/**
 * Template hooks Single Instructor.
 *
 * @since 4.2.3.5
 * @version 1.0.0
 */
namespace LearnPress\TemplateHooks\UserItem;

use LearnPress\Helpers\Template;
use LP_User_Item_Course;

class UserCourseTemplate extends UserItemBaseTemplate {

}
