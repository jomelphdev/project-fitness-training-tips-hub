<?php
/**
 * List template tools database.
 *
 * @author  ThimPress
 * @package LearnPress/Admin/Views
 * @version 3.0.0
 */

defined( 'ABSPATH' ) || die();

require_once 'database/html-upgrade-database.php';
require_once 'database/html-create-indexs-tables.php';
require_once 'database/html-rollback-db.php';
require_once 'database/html-reupgrade-db.php';
require_once 'database/html-clean-database.php';
