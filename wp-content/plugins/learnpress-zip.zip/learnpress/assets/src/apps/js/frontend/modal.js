import Modal from './modal/index';

export default Modal;
